package com.example.dream_house.model;
import lombok.Data;
@Data       // 自动生成getter/setter/toString/hashCode/equals等方法
public class Users {
    private Integer id;
    private String username;
    private String password;
}