package com.example.dream_house.service;
import com.example.dream_house.model.Users;

public interface UsersService {
    //根据用户名查询数据库
    Users findByUser(String uname);
    //注册  将用户名和密码添加到数据库中
    void register(String uname, String psw);
}