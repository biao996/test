package com.example.dream_house.service;
import com.example.dream_house.model.Users;
import com.example.dream_house.mapper.UsersMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsersServiceimpl implements UsersService {

    @Autowired
    private UsersMapper usersMapper;

    @Override
    public Users findByUser(String uname) {
        Users u = usersMapper.findByUser(uname);
        return u;
    }

    @Override
    public void register(String uname, String psw) {
        usersMapper.add(uname,psw);
    }
}
