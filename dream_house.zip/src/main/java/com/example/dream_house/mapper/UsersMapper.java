package com.example.dream_house.mapper;

import com.example.dream_house.model.Users;
import com.example.dream_house.model.Result;
import java.util.List;
import org.apache.ibatis.annotations.*;

@Mapper
public interface UsersMapper {
    //查询
    @Select("select * from users where username = #{uname}")
    Users findByUser(String uname);
    //新增
    @Insert("insert into users(username, password)" +"values  (#{uname},#{psw})")
    void add(String uname, String psw);
}